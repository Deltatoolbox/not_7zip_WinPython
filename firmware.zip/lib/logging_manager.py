import logging
from logging.handlers import RotatingFileHandler

# Create loggers
action_logger = logging.getLogger("action_logger")
debug_logger = logging.getLogger("debug_logger")

def setup_logger(action_log_file, debug_log_file=None, action_level=logging.INFO, 
                 debug_enabled=False, max_bytes=10485760, backup_count=5):
    """
    Setup both action logger and debug logger.
    
    :param action_log_file: Path to the log file for actions.
    :param debug_log_file: Path to the log file for debug logs (optional, can be None).
    :param action_level: Logging level for actions (default INFO).
    :param debug_enabled: Whether to enable the debug log (default False).
    :param max_bytes: Maximum file size before rotating logs (default 10 MB).
    :param backup_count: Number of backup log files to keep (default 5).
    :return: None
    """
    
    # Setup Action Logger
    if action_logger.hasHandlers():
        action_logger.handlers.clear()
    
    action_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    action_handler = RotatingFileHandler(action_log_file, maxBytes=max_bytes, backupCount=backup_count)
    action_handler.setFormatter(action_formatter)
    action_logger.addHandler(action_handler)
    action_logger.setLevel(action_level)
    action_logger.info("Action logger initialized")
    
    # Setup Debug Logger (only if debug is enabled)
    if debug_logger.hasHandlers():
        debug_logger.handlers.clear()
    
    if debug_enabled and debug_log_file:
        debug_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s - [%(filename)s:%(lineno)d]')
        debug_handler = RotatingFileHandler(debug_log_file, maxBytes=max_bytes, backupCount=backup_count)
        debug_handler.setFormatter(debug_formatter)
        debug_logger.addHandler(debug_handler)
        debug_logger.setLevel(logging.DEBUG)
        debug_logger.debug("Debug logger initialized")
    else:
        debug_logger.disabled = True  # Disable the debug logger if not enabled

def enable_debug_logging(debug_log_file, max_bytes=10485760, backup_count=5):
    """
    Enable debug logging and set up the debug logger.
    
    :param debug_log_file: Path to the log file for debug logs.
    :param max_bytes: Maximum file size before rotating logs (default 10 MB).
    :param backup_count: Number of backup log files to keep (default 5).
    :return: None
    """
    if debug_logger.hasHandlers():
        debug_logger.handlers.clear()
    
    debug_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s - [%(filename)s:%(lineno)d]')
    debug_handler = RotatingFileHandler(debug_log_file, maxBytes=max_bytes, backupCount=backup_count)
    debug_handler.setFormatter(debug_formatter)
    debug_logger.addHandler(debug_handler)
    debug_logger.setLevel(logging.DEBUG)
    debug_logger.disabled = False  # Re-enable the debug logger
    debug_logger.debug("Debug logger enabled")

def disable_debug_logging():
    """
    Disable the debug logger.
    
    :return: None
    """
    debug_logger.disabled = True
    debug_logger.debug("Debug logger disabled")

# Log action (INFO level)
def log_action(message):
    """
    Log a message to the action log.
    
    :param message: The action message to log.
    :return: None
    """
    action_logger.info(message)

# Log debug (DEBUG level)
def log_debug(message):
    """
    Log a debug message to the debug log (if enabled).
    
    :param message: The debug message to log.
    :return: None
    """
    if not debug_logger.disabled:
        debug_logger.debug(message)
