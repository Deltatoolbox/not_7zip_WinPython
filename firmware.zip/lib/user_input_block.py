from pynput import keyboard, mouse
import time
from threading import Timer

# Global variables for listeners
keyboard_listener = keyboard.Listener(suppress=True)
mouse_listener = mouse.Listener(suppress=True)
input_blocked = False


def block_input():
    """
    Block both keyboard and mouse input by using pynput listeners.
    """
    global input_blocked
    if(not input_blocked):
        
        keyboard_listener.start()
        mouse_listener.start()
        input_blocked = True
        return "The user input is blocked"
    else:
        return "The user input is already blocked"
        
    

def unblock_input():
    """
    Unblock keyboard and mouse input by stopping the listeners.
    """
    global input_blocked
    if(input_blocked):
        keyboard_listener.stop()
        mouse_listener.stop()
        input_blocked = False
        return "The user input is unblocked"
    else:
        return "The user input is already unblocked"
