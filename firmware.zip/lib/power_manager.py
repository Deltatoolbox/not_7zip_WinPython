import os
import subprocess
from .logging_manager import log_action, log_debug

# Shutdown the computer
def shutdown():
    """
    Shutdown the computer.
    
    :return: Success or error message.
    """
    try:
        subprocess.run(["shutdown", "/s", "/t", "0"], shell=True)
        log_action("Shutdown command issued.")
        return "The computer is shutting down."
    except Exception as e:
        log_debug(f"Failed to shutdown the computer. Error: {str(e)}")
        return f"Error: {str(e)}"

# Restart the computer
def restart():
    """
    Restart the computer.
    
    :return: Success or error message.
    """
    try:
        subprocess.run(["shutdown", "/r", "/t", "0"], shell=True)
        log_action("Restart command issued.")
        return "The computer is restarting."
    except Exception as e:
        log_debug(f"Failed to restart the computer. Error: {str(e)}")
        return f"Error: {str(e)}"

# Log off the current user
def logoff():
    """
    Log off the current user.
    
    :return: Success or error message.
    """
    try:
        subprocess.run(["shutdown", "/l"], shell=True)
        log_action("Logoff command issued.")
        return "The user is logging off."
    except Exception as e:
        log_debug(f"Failed to log off. Error: {str(e)}")
        return f"Error: {str(e)}"

# Put the computer to sleep (Windows only)
def sleep():
    """
    Put the computer to sleep.
    
    :return: Success or error message.
    """
    try:
        subprocess.run(["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"], shell=True)
        log_action("Sleep command issued.")
        return "The computer is going to sleep."
    except Exception as e:
        log_debug(f"Failed to put the computer to sleep. Error: {str(e)}")
        return f"Error: {str(e)}"

# Hibernate the computer (Windows only)
def hibernate():
    """
    Put the computer into hibernation mode.
    
    :return: Success or error message.
    """
    try:
        subprocess.run(["shutdown", "/h"], shell=True)
        log_action("Hibernate command issued.")
        return "The computer is going into hibernation."
    except Exception as e:
        log_debug(f"Failed to hibernate the computer. Error: {str(e)}")
        return f"Error: {str(e)}"
