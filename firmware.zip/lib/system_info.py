import psutil
import platform
import socket
from datetime import datetime
from .logging_manager import log_action, log_debug

# Get CPU information
def get_cpu_info():
    """
    Get CPU details including cores, usage, and frequency.
    :return: Dictionary with CPU information.
    """
    try:
        cpu_info = {
            "physical_cores": psutil.cpu_count(logical=False),
            "total_cores": psutil.cpu_count(logical=True),
            "cpu_usage_percent": psutil.cpu_percent(interval=1),
            "cpu_frequency": psutil.cpu_freq().current
        }
        log_action("Retrieved CPU information")
        return cpu_info
    except Exception as e:
        log_debug(f"Failed to retrieve CPU info. Error: {str(e)}")
        return f"Error: {str(e)}"

# Get memory information
def get_memory_info():
    """
    Get memory details including total, used, and available memory.
    :return: Dictionary with memory information.
    """
    try:
        memory = psutil.virtual_memory()
        memory_info = {
            "total_memory_gb": memory.total / (1024 ** 3),
            "used_memory_gb": memory.used / (1024 ** 3),
            "available_memory_gb": memory.available / (1024 ** 3),
            "memory_usage_percent": memory.percent
        }
        log_action("Retrieved memory information")
        return memory_info
    except Exception as e:
        log_debug(f"Failed to retrieve memory info. Error: {str(e)}")
        return f"Error: {str(e)}"

# Get disk information
def get_disk_info():
    """
    Get disk usage details including partitions and disk usage.
    :return: List of dictionaries with disk partition and usage information.
    """
    try:
        partitions = psutil.disk_partitions()
        disk_info = []
        for partition in partitions:
            usage = psutil.disk_usage(partition.mountpoint)
            disk_info.append({
                "device": partition.device,
                "mountpoint": partition.mountpoint,
                "total_gb": usage.total / (1024 ** 3),
                "used_gb": usage.used / (1024 ** 3),
                "free_gb": usage.free / (1024 ** 3),
                "usage_percent": usage.percent
            })
        log_action("Retrieved disk information")
        return disk_info
    except Exception as e:
        log_debug(f"Failed to retrieve disk info. Error: {str(e)}")
        return f"Error: {str(e)}"

# Get network information
def get_network_info():
    """
    Get network information including hostname, IP address, and more.
    :return: Dictionary with network information.
    """
    try:
        hostname = socket.gethostname()
        ip_address = socket.gethostbyname(hostname)
        network_info = {
            "hostname": hostname,
            "ip_address": ip_address
        }
        log_action("Retrieved network information")
        return network_info
    except Exception as e:
        log_debug(f"Failed to retrieve network info. Error: {str(e)}")
        return f"Error: {str(e)}"

# Get OS information
def get_os_info():
    """
    Get OS information including name, version, and architecture.
    :return: Dictionary with OS information.
    """
    try:
        os_info = {
            "system": platform.system(),
            "node_name": platform.node(),
            "release": platform.release(),
            "version": platform.version(),
            "architecture": platform.architecture()[0]
        }
        log_action("Retrieved OS information")
        return os_info
    except Exception as e:
        log_debug(f"Failed to retrieve OS info. Error: {str(e)}")
        return f"Error: {str(e)}"

# Get all system information
def get_all_system_info():
    """
    Retrieve all system information including CPU, memory, disk, network, and OS details.
    :return: Dictionary containing all system information.
    """
    try:
        system_info = {
            "cpu_info": get_cpu_info(),
            "memory_info": get_memory_info(),
            "disk_info": get_disk_info(),
            "network_info": get_network_info(),
            "os_info": get_os_info(),
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        log_action("Retrieved complete system information")
        return system_info
    except Exception as e:
        log_debug(f"Failed to retrieve all system info. Error: {str(e)}")
        return f"Error: {str(e)}"
