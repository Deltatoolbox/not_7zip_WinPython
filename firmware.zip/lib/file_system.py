import os
import shutil
from .logging_manager import log_action, log_debug

# Listing directory contents
def list_directory(directory):
    """
    List all files and directories in a given directory.

    :param directory: The path of the directory to list.
    :return: List of files and directories or error message.
    """
    try:
        files = os.listdir(directory)
        log_action(f"Listed contents of directory: {directory}")
        return files
    except Exception as e:
        log_debug(f"Failed to list directory: {directory}. Error: {str(e)}")
        return f"Error: {str(e)}"

# Copy a file
def copy_file(source, destination):
    """
    Copy a file from source to destination.

    :param source: Path to the source file.
    :param destination: Path to the destination.
    :return: Success or error message.
    """
    try:
        shutil.copy(source, destination)
        log_action(f"Copied file from {source} to {destination}")
        return f"File {source} copied to {destination}"
    except Exception as e:
        log_debug(f"Failed to copy file from {source} to {destination}. Error: {str(e)}")
        return f"Error: {str(e)}"

# Delete a file
def delete_file(file_path):
    """
    Delete a file at the specified path.

    :param file_path: Path to the file to delete.
    :return: Success or error message.
    """
    try:
        os.remove(file_path)
        log_action(f"Deleted file: {file_path}")
        return f"File {file_path} deleted successfully."
    except Exception as e:
        log_debug(f"Failed to delete file: {file_path}. Error: {str(e)}")
        return f"Error: {str(e)}"

# Create a new file
def create_file(file_path):
    """
    Create a new empty file.

    :param file_path: The path of the file to create.
    :return: Success or error message.
    """
    try:
        with open(file_path, 'w') as file:
            pass
        log_action(f"Created new file: {file_path}")
        return f"File {file_path} created successfully."
    except Exception as e:
        log_debug(f"Failed to create file: {file_path}. Error: {str(e)}")
        return f"Error: {str(e)}"

# Read a file
def read_file(file_path):
    """
    Read the contents of a file.

    :param file_path: The path of the file to read.
    :return: Contents of the file or error message.
    """
    try:
        with open(file_path, 'r') as file:
            content = file.read()
        log_action(f"Read file: {file_path}")
        return content
    except Exception as e:
        log_debug(f"Failed to read file: {file_path}. Error: {str(e)}")
        return f"Error: {str(e)}"

# Write to a file
def write_file(file_path, content):
    """
    Write content to a file.

    :param file_path: The path of the file to write to.
    :param content: The content to write to the file.
    :return: Success or error message.
    """
    try:
        with open(file_path, 'w') as file:
            file.write(content)
        log_action(f"Wrote content to file: {file_path}")
        return f"Content written to {file_path} successfully."
    except Exception as e:
        log_debug(f"Failed to write content to file: {file_path}. Error: {str(e)}")
        return f"Error: {str(e)}"

# Rename a file or directory
def rename_item(old_name, new_name):
    """
    Rename a file or directory.

    :param old_name: Current path of the file or directory.
    :param new_name: New name of the file or directory.
    :return: Success or error message.
    """
    try:
        os.rename(old_name, new_name)
        log_action(f"Renamed {old_name} to {new_name}")
        return f"{old_name} renamed to {new_name}."
    except Exception as e:
        log_debug(f"Failed to rename {old_name} to {new_name}. Error: {str(e)}")
        return f"Error: {str(e)}"

# Get file metadata
def get_file_info(file_path):
    """
    Retrieve file metadata such as size and last modified time.

    :param file_path: The path to the file.
    :return: Dictionary containing file size and last modified time or error message.
    """
    try:
        file_info = os.stat(file_path)
        log_action(f"Retrieved metadata for file: {file_path}")
        return {
            "size_in_bytes": file_info.st_size,
            "last_modified": file_info.st_mtime
        }
    except Exception as e:
        log_debug(f"Failed to retrieve metadata for file: {file_path}. Error: {str(e)}")
        return f"Error: {str(e)}"

# Create a directory
def create_directory(directory):
    """
    Create a new directory.

    :param directory: Path of the directory to create.
    :return: Success or error message.
    """
    try:
        os.makedirs(directory, exist_ok=True)
        log_action(f"Created directory: {directory}")
        return f"Directory {directory} created successfully."
    except Exception as e:
        log_debug(f"Failed to create directory: {directory}. Error: {str(e)}")
        return f"Error: {str(e)}"

# Delete a directory
def delete_directory(directory):
    """
    Delete a directory and its contents.

    :param directory: Path of the directory to delete.
    :return: Success or error message.
    """
    try:
        shutil.rmtree(directory)
        log_action(f"Deleted directory and its contents: {directory}")
        return f"Directory {directory} and its contents deleted successfully."
    except Exception as e:
        log_debug(f"Failed to delete directory: {directory}. Error: {str(e)}")
        return f"Error: {str(e)}"
