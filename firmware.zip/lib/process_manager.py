import subprocess
from .logging_manager import log_action, log_debug

# List all running processes
def list_processes():
    """
    List all running processes on the system using PowerShell.
    
    :return: List of processes or an error message.
    """
    try:
        result = subprocess.run("powershell.exe Get-Process", shell=True, capture_output=True, text=True)
        log_action("Listed all running processes")
        return result.stdout
    except Exception as e:
        log_debug(f"Failed to list processes. Error: {str(e)}")
        return f"Error: {str(e)}"

# Kill a process by name or process ID
def kill_process(process_name_or_id):
    """
    Kill a process by name or process ID.
    
    :param process_name_or_id: Name or ID of the process to terminate.
    :return: Success or error message.
    """
    try:
        result = subprocess.run(f"taskkill /F /IM {process_name_or_id}", shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            log_action(f"Terminated process {process_name_or_id}")
            return f"Process {process_name_or_id} terminated successfully."
        else:
            log_debug(f"Failed to terminate process {process_name_or_id}. Error: {result.stderr}")
            return f"Error: {result.stderr}"
    except Exception as e:
        log_debug(f"Failed to terminate process {process_name_or_id}. Exception: {str(e)}")
        return f"Exception: {str(e)}"

# Start a new process using CMD
def start_process(command):
    """
    Start a new process using CMD.
    
    :param command: The command to start the process.
    :return: Output or error message.
    """
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        log_action(f"Started process with command: {command}")
        return result.stdout
    except Exception as e:
        log_debug(f"Failed to start process with command: {command}. Error: {str(e)}")
        return f"Error: {str(e)}"
