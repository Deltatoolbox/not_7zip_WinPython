import time
import winsound
import threading
from .logging_manager import log_action, log_debug  # Assuming logging_manager is in the same directory

def beep():
    """
    Emit a beep sound using the winsound library (Windows only).
    """
    try:
        winsound.Beep(1000, 500)  # Frequency: 1000 Hz, Duration: 500 ms
        log_action("Beep sound emitted.")
    except Exception as e:
        log_debug(f"Failed to emit beep sound. Error: {str(e)}")

def beep_loop(interval, duration):
    """
    Continuously emits beep sounds at the given interval for a set duration.
    
    :param interval: Time in seconds between each beep.
    :param duration: Total time in seconds to run the beep loop.
    :return: None
    """
    start_time = time.time()
    try:
        while time.time() - start_time < float(duration):
            beep()  # Emit beep sound
            time.sleep(float(interval))  # Sleep for the given interval
        log_action("Beep loop finished.")
    except Exception as e:
        log_debug(f"Beep loop interrupted. Error: {str(e)}")

def start_beep_thread(interval, duration):
    """
    Start the beep loop in a separate thread.
    
    :param interval: Time in seconds between each beep.
    :param duration: Total time in seconds to run the beep loop.
    :return: Thread object
    """
    beep_thread = threading.Thread(target=beep_loop, args=(interval, duration))
    beep_thread.start()  # Start the thread
    return beep_thread


