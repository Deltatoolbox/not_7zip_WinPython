import subprocess
from .logging_manager import log_action, log_debug

# Create a new scheduled task
def create_task(task_name, command, start_time, interval='daily'):
    """
    Create a new scheduled task in Windows Task Scheduler.
    
    :param task_name: The name of the task.
    :param command: The command or script to run.
    :param start_time: The time to start the task (in HH:mm format).
    :param interval: The interval at which the task should run (daily, weekly, once).
    :return: Success or error message.
    """
    try:
        result = subprocess.run(
            ["schtasks", "/create", "/tn", task_name, "/tr", command, "/sc", interval, "/st", start_time],
            capture_output=True, text=True, shell=True
        )
        if result.returncode == 0:
            log_action(f"Created task '{task_name}' to run '{command}' at {start_time} every {interval}.")
            return f"Task '{task_name}' created successfully."
        else:
            log_debug(f"Failed to create task '{task_name}'. Error: {result.stderr}")
            return f"Error: {result.stderr}"
    except Exception as e:
        log_debug(f"Exception while creating task '{task_name}'. Error: {str(e)}")
        return f"Exception: {str(e)}"

# List all scheduled tasks
def list_tasks():
    """
    List all scheduled tasks in Windows Task Scheduler.
    
    :return: Output of the scheduled tasks or an error message.
    """
    try:
        result = subprocess.run(["schtasks"], capture_output=True, text=True, shell=True)
        if result.returncode == 0:
            log_action("Listed all scheduled tasks.")
            return result.stdout
        else:
            log_debug(f"Failed to list scheduled tasks. Error: {result.stderr}")
            return f"Error: {result.stderr}"
    except Exception as e:
        log_debug(f"Exception while listing scheduled tasks. Error: {str(e)}")
        return f"Exception: {str(e)}"

# Delete a scheduled task
def delete_task(task_name):
    """
    Delete a scheduled task by name.
    
    :param task_name: The name of the task to delete.
    :return: Success or error message.
    """
    try:
        result = subprocess.run(
            ["schtasks", "/delete", "/tn", task_name, "/f"], capture_output=True, text=True, shell=True
        )
        if result.returncode == 0:
            log_action(f"Deleted task '{task_name}'.")
            return f"Task '{task_name}' deleted successfully."
        else:
            log_debug(f"Failed to delete task '{task_name}'. Error: {result.stderr}")
            return f"Error: {result.stderr}"
    except Exception as e:
        log_debug(f"Exception while deleting task '{task_name}'. Error: {str(e)}")
        return f"Exception: {str(e)}"

# Run a task immediately
def run_task(task_name):
    """
    Run a scheduled task immediately by name.
    
    :param task_name: The name of the task to run.
    :return: Success or error message.
    """
    try:
        result = subprocess.run(
            ["schtasks", "/run", "/tn", task_name], capture_output=True, text=True, shell=True
        )
        if result.returncode == 0:
            log_action(f"Ran task '{task_name}' immediately.")
            return f"Task '{task_name}' started successfully."
        else:
            log_debug(f"Failed to run task '{task_name}'. Error: {result.stderr}")
            return f"Error: {result.stderr}"
    except Exception as e:
        log_debug(f"Exception while running task '{task_name}'. Error: {str(e)}")
        return f"Exception: {str(e)}"
