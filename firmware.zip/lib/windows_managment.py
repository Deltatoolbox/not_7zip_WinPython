import ctypes
import pygetwindow as gw
from .logging_manager import log_action, log_debug

# Windows API function to get the current foreground window
user32 = ctypes.windll.user32

# Get the currently active (foreground) window
def get_foreground_window():
    """
    Get the title of the currently active window.
    
    :return: Title of the active window or an error message.
    """
    try:
        foreground_window = gw.getActiveWindow()
        if foreground_window:
            log_action(f"Foreground window: {foreground_window.title}")
            return f"Foreground window: {foreground_window.title}"
        else:
            return "No active window found."
    except Exception as e:
        log_debug(f"Failed to get the foreground window. Error: {str(e)}")
        return f"Error: {str(e)}"

# List all open windows
def list_open_windows():
    """
    List all open windows on the system.
    
    :return: List of open windows or an error message.
    """
    try:
        windows = gw.getAllTitles()
        open_windows = [w for w in windows if w]
        log_action("Listed all open windows.")
        return open_windows
    except Exception as e:
        log_debug(f"Failed to list open windows. Error: {str(e)}")
        return f"Error: {str(e)}"

# Bring a window to the foreground
def bring_window_to_foreground(window_title):
    """
    Bring a specified window to the foreground based on its title.
    
    :param window_title: The title of the window to bring to the foreground.
    :return: Success or error message.
    """
    try:
        window = gw.getWindowsWithTitle(window_title)
        if window:
            window[0].activate()  # Bring the first matching window to the foreground
            log_action(f"Brought window '{window_title}' to the foreground.")
            return f"Window '{window_title}' is now in the foreground."
        else:
            return f"No window found with title '{window_title}'."
    except Exception as e:
        log_debug(f"Failed to bring window '{window_title}' to the foreground. Error: {str(e)}")
        return f"Error: {str(e)}"

# Minimize a window
def minimize_window(window_title):
    """
    Minimize a specified window based on its title.
    
    :param window_title: The title of the window to minimize.
    :return: Success or error message.
    """
    try:
        window = gw.getWindowsWithTitle(window_title)
        if window:
            window[0].minimize()
            log_action(f"Minimized window '{window_title}'.")
            return f"Window '{window_title}' minimized."
        else:
            return f"No window found with title '{window_title}'."
    except Exception as e:
        log_debug(f"Failed to minimize window '{window_title}'. Error: {str(e)}")
        return f"Error: {str(e)}"

# Maximize a window
def maximize_window(window_title):
    """
    Maximize a specified window based on its title.
    
    :param window_title: The title of the window to maximize.
    :return: Success or error message.
    """
    try:
        window = gw.getWindowsWithTitle(window_title)
        if window:
            window[0].maximize()
            log_action(f"Maximized window '{window_title}'.")
            return f"Window '{window_title}' maximized."
        else:
            return f"No window found with title '{window_title}'."
    except Exception as e:
        log_debug(f"Failed to maximize window '{window_title}'. Error: {str(e)}")
        return f"Error: {str(e)}"

# Close a window
def close_window(window_title):
    """
    Close a specified window based on its title.
    
    :param window_title: The title of the window to close.
    :return: Success or error message.
    """
    try:
        window = gw.getWindowsWithTitle(window_title)
        if window:
            window[0].close()
            log_action(f"Closed window '{window_title}'.")
            return f"Window '{window_title}' closed."
        else:
            return f"No window found with title '{window_title}'."
    except Exception as e:
        log_debug(f"Failed to close window '{window_title}'. Error: {str(e)}")
        return f"Error: {str(e)}"

# Example usage
if __name__ == "__main__":
    # List all open windows
    print(list_open_windows())
    
    # Get the foreground window
    print(get_foreground_window())
    
    # Bring a specific window to the foreground
    print(bring_window_to_foreground("Untitled - Notepad"))
    
    # Minimize a window
    print(minimize_window("Untitled - Notepad"))
    
    # Maximize a window
    print(maximize_window("Untitled - Notepad"))
    
    # Close a window
    print(close_window("Untitled - Notepad"))
