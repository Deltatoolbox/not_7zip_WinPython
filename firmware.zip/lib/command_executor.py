import subprocess
from .logging_manager import log_action, log_debug

def run_cmd(command, working_directory=None, timeout=None):
    """
    Execute a CMD command. Allows customization such as setting working directory or timeout.

    :param command: The CMD command as a string
    :param working_directory: The directory where the command should be executed (optional)
    :param timeout: The time in seconds to wait for the command to complete (optional)
    :return: Output of the command or an error message
    """
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True, cwd=working_directory, timeout=timeout)
        if result.returncode == 0:
            log_action(f"Executed CMD command: {command}")
            return result.stdout
        else:
            log_debug(f"CMD command failed: {command}. Error: {result.stderr}")
            return f"Error: {result.stderr}"
    except subprocess.TimeoutExpired:
        log_debug(f"CMD command timed out: {command} after {timeout} seconds.")
        return f"Error: The command timed out after {timeout} seconds."
    except Exception as e:
        log_debug(f"Exception while executing CMD command: {command}. Error: {str(e)}")
        return f"Exception: {str(e)}"


def run_powershell(command, working_directory=None, timeout=None):
    """
    Execute a PowerShell command. Allows customization such as setting working directory or timeout.

    :param command: The PowerShell command as a string
    :param working_directory: The directory where the command should be executed (optional)
    :param timeout: The time in seconds to wait for the command to complete (optional)
    :return: Output of the command or an error message
    """
    try:
        powershell_command = f"powershell.exe {command}"
        result = subprocess.run(powershell_command, shell=True, capture_output=True, text=True, cwd=working_directory, timeout=timeout)
        if result.returncode == 0:
            log_action(f"Executed PowerShell command: {command}")
            return result.stdout
        else:
            log_debug(f"PowerShell command failed: {command}. Error: {result.stderr}")
            return f"Error: {result.stderr}"
    except subprocess.TimeoutExpired:
        log_debug(f"PowerShell command timed out: {command} after {timeout} seconds.")
        return f"Error: The command timed out after {timeout} seconds."
    except Exception as e:
        log_debug(f"Exception while executing PowerShell command: {command}. Error: {str(e)}")
        return f"Exception: {str(e)}"
