import os
import fnmatch
from .logging_manager import log_action, log_debug

# Function to search for files by extension
def search_by_extension(root_directory, file_extension, recursive=True):
    """
    Search for files by extension in a given directory and optionally all subdirectories.
    
    :param root_directory: The directory to start searching in.
    :param file_extension: The file extension to search for (e.g., '.txt').
    :param recursive: Whether to search recursively in subdirectories (default is True).
    :return: List of matching file paths.
    """
    results = []
    try:
        for dirpath, _, filenames in os.walk(root_directory):
            for filename in filenames:
                if filename.endswith(file_extension):
                    file_path = os.path.join(dirpath, filename)
                    log_action(f"Found file with extension {file_extension}: {file_path}")
                    results.append(file_path)

            if not recursive:
                break
        log_action(f"Search for extension {file_extension} completed.")
    except Exception as e:
        log_debug(f"Error during search by extension. Error: {str(e)}")
    return results

# Function to search for files by name pattern (e.g., '*.txt')
def search_by_filename(root_directory, file_name_pattern, recursive=True):
    """
    Search for files by name pattern (supports wildcards).
    
    :param root_directory: The directory to start searching in.
    :param file_name_pattern: The pattern for matching filenames (e.g., '*.txt').
    :param recursive: Whether to search recursively in subdirectories (default is True).
    :return: List of matching file paths.
    """
    results = []
    try:
        for dirpath, _, filenames in os.walk(root_directory):
            for filename in filenames:
                if fnmatch.fnmatch(filename, file_name_pattern):
                    file_path = os.path.join(dirpath, filename)
                    log_action(f"Found file matching {file_name_pattern}: {file_path}")
                    results.append(file_path)

            if not recursive:
                break
        log_action(f"Search for filename pattern {file_name_pattern} completed.")
    except Exception as e:
        log_debug(f"Error during search by filename. Error: {str(e)}")
    return results

# Function to search for folders by name
def search_by_foldername(root_directory, folder_name, recursive=True):
    """
    Search for folders by name.
    
    :param root_directory: The directory to start searching in.
    :param folder_name: The name of the folder to search for.
    :param recursive: Whether to search recursively in subdirectories (default is True).
    :return: List of matching folder paths.
    """
    results = []
    try:
        for dirpath, dirnames, _ in os.walk(root_directory):
            for dirname in dirnames:
                if fnmatch.fnmatch(dirname, folder_name):
                    folder_path = os.path.join(dirpath, dirname)
                    log_action(f"Found folder matching {folder_name}: {folder_path}")
                    results.append(folder_path)

            if not recursive:
                break
        log_action(f"Search for folder name {folder_name} completed.")
    except Exception as e:
        log_debug(f"Error during search by folder name. Error: {str(e)}")
    return results

# Function to search within files for specific content
def search_by_file_content(root_directory, search_content, recursive=True):
    """
    Search within files for specific content.
    
    :param root_directory: The directory to start searching in.
    :param search_content: The content to search for within files.
    :param recursive: Whether to search recursively in subdirectories (default is True).
    :return: List of matching file paths.
    """
    results = []
    try:
        for dirpath, _, filenames in os.walk(root_directory):
            for filename in filenames:
                file_path = os.path.join(dirpath, filename)
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as file:
                        content = file.read()
                        if search_content in content:
                            log_action(f"Found content match in file: {file_path}")
                            results.append(file_path)
                except Exception as e:
                    log_debug(f"Error reading file {file_path}. Error: {str(e)}")

            if not recursive:
                break
        log_action(f"Search for file content '{search_content}' completed.")
    except Exception as e:
        log_debug(f"Error during search by file content. Error: {str(e)}")
    return results
