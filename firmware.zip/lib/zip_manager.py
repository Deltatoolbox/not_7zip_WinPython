import zipfile
import os
from .logging_manager import log_action, log_debug

# Zip a single file
def zip_file(file_path, zip_name):
    """
    Compress a single file into a zip archive.

    :param file_path: The path of the file to compress.
    :param zip_name: The name of the resulting zip file.
    :return: Success or error message.
    """
    try:
        with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
            zipf.write(file_path, os.path.basename(file_path))
        log_action(f"Compressed file {file_path} into {zip_name}")
        return f"File {file_path} compressed into {zip_name}."
    except Exception as e:
        log_debug(f"Failed to compress file {file_path} into {zip_name}. Error: {str(e)}")
        return f"Error: {str(e)}"


# Zip an entire directory
def zip_directory(directory_path, zip_name):
    """
    Compress an entire directory into a zip archive.

    :param directory_path: The path of the directory to compress.
    :param zip_name: The name of the resulting zip file.
    :return: Success or error message.
    """
    try:
        with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(directory_path):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, directory_path)
                    zipf.write(file_path, arcname)
        log_action(f"Compressed directory {directory_path} into {zip_name}")
        return f"Directory {directory_path} compressed into {zip_name}."
    except Exception as e:
        log_debug(f"Failed to compress directory {directory_path} into {zip_name}. Error: {str(e)}")
        return f"Error: {str(e)}"


# Extract a zip file
def extract_zip(zip_path, extract_to):
    """
    Extract a zip file to the specified directory.

    :param zip_path: The path of the zip file to extract.
    :param extract_to: The directory where the files should be extracted.
    :return: Success or error message.
    """
    try:
        with zipfile.ZipFile(zip_path, 'r') as zipf:
            zipf.extractall(extract_to)
        log_action(f"Extracted zip file {zip_path} to {extract_to}")
        return f"Zip file {zip_path} extracted to {extract_to}."
    except Exception as e:
        log_debug(f"Failed to extract zip file {zip_path} to {extract_to}. Error: {str(e)}")
        return f"Error: {str(e)}"


# List the contents of a zip file
def list_zip_contents(zip_path):
    """
    List the contents of a zip file without extracting it.

    :param zip_path: The path of the zip file.
    :return: List of contents or error message.
    """
    try:
        with zipfile.ZipFile(zip_path, 'r') as zipf:
            contents = zipf.namelist()
        log_action(f"Listed contents of zip file {zip_path}")
        return contents
    except Exception as e:
        log_debug(f"Failed to list contents of zip file {zip_path}. Error: {str(e)}")
        return f"Error: {str(e)}"
