import os
import time
import pyautogui
import cv2
from PIL import ImageGrab
from datetime import datetime
from .logging_manager import log_action, log_debug
import numpy as np

# Capture a screenshot for all screens (multi-monitor)
def capture_screenshot(output_path="screenshot.png"):
    """
    Capture a screenshot of all screens (multi-monitor setup) and save it as an image.
    
    :param output_path: The file path where the screenshot will be saved.
    :return: Success or error message.
    """
    try:
        # Capture the entire virtual screen (including all monitors)
        screenshot = ImageGrab.grab(all_screens=True)

        # Ensure the output directory exists
        output_directory = os.path.dirname(output_path)
        if output_directory and not os.path.exists(output_directory):
            os.makedirs(output_directory)

        # Save the screenshot
        screenshot.save(output_path)
        log_action(f"Screenshot captured and saved at {output_path}")
        return f"Screenshot saved at {output_path}"
    except Exception as e:
        log_debug(f"Failed to capture screenshot. Error: {str(e)}")
        return f"Error: {str(e)}"

def record_screen(output_path="screen_recording.avi", duration=10, fps=20):
    """
    Record the screen for a specific duration and save it as a video.

    :param output_path: The file path where the screen recording will be saved.
    :param duration: The duration (in seconds) of the recording.
    :param fps: Frames per second for the video recording.
    :return: Success or error message.
    """
    try:
        # Capture the size of the entire screen (considering multiple monitors)
        screenshot = ImageGrab.grab(all_screens=True)
        screen_size = screenshot.size  # Get the size of the screenshot
        
        # Ensure the output file name is valid
        if not output_path.lower().endswith('.avi'):
            output_path += ".avi"

        # Define the codec and create VideoWriter object
        fourcc = cv2.VideoWriter_fourcc(*"XVID")
        out = cv2.VideoWriter(output_path, fourcc, fps, screen_size)

        if not out.isOpened():
            log_debug("Failed to open VideoWriter.")
            return "Error: Failed to open VideoWriter."

        log_action(f"Started screen recording for {duration} seconds")

        start_time = time.time()

        while True:
            # Capture the current screen
            img = ImageGrab.grab(all_screens=True)
            img_np = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)

            # Write the frame to the video file
            out.write(img_np)

            # Stop recording after the duration is exceeded
            if time.time() - start_time > duration:
                break

        out.release()  # Release the video file
        log_action(f"Screen recording saved at {output_path}")
        return f"Screen recording saved at {output_path}"
    
    except Exception as e:
        log_debug(f"Failed to record screen. Error: {str(e)}")
        return f"Error: {str(e)}"


# Take a screenshot at specific intervals for a certain duration
def capture_screenshots_interval(output_folder="screenshots", interval=5, total_duration=30):
    """
    Capture screenshots at regular intervals for a specific duration.
    
    :param output_folder: Folder to save the screenshots.
    :param interval: Time interval (in seconds) between screenshots.
    :param total_duration: Total duration (in seconds) over which to capture screenshots.
    :return: Success or error message.
    """
    try:
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

        start_time = time.time()
        screenshot_count = 0

        while True:
            if time.time() - start_time > total_duration:
                break

            screenshot_path = os.path.join(output_folder, f"screenshot_{screenshot_count}.png")
            capture_screenshot(screenshot_path)
            screenshot_count += 1

            # Wait for the specified interval
            time.sleep(interval)

        log_action(f"Captured {screenshot_count} screenshots at {interval}-second intervals.")
        return f"Captured {screenshot_count} screenshots."
    except Exception as e:
        log_debug(f"Failed to capture screenshots at intervals. Error: {str(e)}")
        return f"Error: {str(e)}"
