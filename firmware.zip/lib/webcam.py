import cv2
import time
from .logging_manager import log_action, log_debug

# Capture an image from the webcam
def capture_webcam_image(output_path="webcam_image.png"):
    """
    Capture a single image from the webcam and save it as an image file.

    :param output_path: The file path where the image will be saved.
    :return: Success or error message.
    """
    try:
        # Open the default webcam (0)
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            raise Exception("Could not access webcam.")

        # Capture a single frame
        ret, frame = cap.read()
        if ret:
            # Save the captured image
            cv2.imwrite(output_path, frame)
            log_action(f"Webcam image captured and saved at {output_path}")
            cap.release()
            return f"Webcam image saved at {output_path}"
        else:
            raise Exception("Failed to capture image from webcam.")
    except Exception as e:
        log_debug(f"Failed to capture webcam image. Error: {str(e)}")
        return f"Error: {str(e)}"

# Record a video from the webcam
def record_webcam_video(output_path="webcam_video.avi", duration=10, fps=20):
    """
    Record a video from the webcam and save it as a video file.

    :param output_path: The file path where the video will be saved.
    :param duration: Duration (in seconds) of the video recording.
    :param fps: Frames per second for the video.
    :return: Success or error message.
    """
    try:
        # Open the default webcam (0)
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            raise Exception("Could not access webcam.")
        
        # Get the default width and height of the frame
        frame_width = int(cap.get(3))
        frame_height = int(cap.get(4))

        # Define the codec and create VideoWriter object
        fourcc = cv2.VideoWriter_fourcc(*"XVID")
        out = cv2.VideoWriter(output_path, fourcc, fps, (frame_width, frame_height))

        log_action(f"Started webcam video recording for {duration} seconds.")

        start_time = time.time()
        while True:
            ret, frame = cap.read()
            if ret:
                # Write the frame into the file
                out.write(frame)

                # Display the live video (optional)
                cv2.imshow('Recording', frame)

                # Exit recording after specified duration
                if time.time() - start_time > duration:
                    break

                # Exit recording on 'q' key press
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
            else:
                raise Exception("Failed to capture video frame from webcam.")

        cap.release()
        out.release()
        cv2.destroyAllWindows()
        log_action(f"Webcam video saved at {output_path}")
        return f"Webcam video saved at {output_path}"
    except Exception as e:
        log_debug(f"Failed to record webcam video. Error: {str(e)}")
        return f"Error: {str(e)}"
